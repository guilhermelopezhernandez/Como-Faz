// Configuração de conexão com o Supabase.
// Pegue esses dois valores em: Painel do Supabase > Project Settings > API
// SUPABASE_URL = "Project URL"
// SUPABASE_ANON_KEY = "anon public" key
// Esses valores NÃO são secretos - são feitos para rodar no navegador.

const SUPABASE_URL = 'COLOQUE_SUA_PROJECT_URL_AQUI';
const SUPABASE_ANON_KEY = 'COLOQUE_SUA_ANON_KEY_AQUI';

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
